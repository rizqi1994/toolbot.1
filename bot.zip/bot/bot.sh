#info
# BY : MOH BAGUS ROMADHONI PRATAMA


clear
echo
echo
echo
echo
toilet -f standard "TOOL BOT" -F gay
echo "_____________________________________________"
echo
echo " Modif By : Moh Bagus Romadhoni Pratama "
echo " Remod By : Rizqi maulana "
echo
echo
echo
echo " Pilih Bot Yang Mau Digunakan "
echo
sleep 0.5
echo " 01. Newscat 		"
echo " 02. Kubik 		"
echo " 03. Cashtree 		"
echo " 04. Veeu		"
echo " 05. Ltc1		"
echo " 06. Ltc2		"
echo " 07. Ltc3		"
echo " 08. Ltc4		"
echo " 09. Ltc5		"
echo " 00. Exit 		"
echo
read -p " select a number -> " rdhoni


	if [ $rdhoni = 1 ] || [ $rdhoni = 01 ]
then

cd $HOME
cd bot
cd NewscatBOT
clear
bash BOT.sh

fi

	if [ $rdhoni = 2 ] || [ $rdhoni = 02 ]
then

cd $HOME
cd bot
cd kubik
clear
php kubik.php

fi

	if [ $rdhoni = 3 ] || [ $rdhoni = 03 ]
then

cd $HOME
cd bot
cd cashtree
clear
php cashtree.php

fi

	if [ $rdhoni = 4 ] || [ $rdhoni = 04 ]
then

cd $HOME
cd bot
cd veeu-master
clear
php bot.php

fi

	if [ $rdhoni = 5 ] || [ $rdhoni = 05 ]
then

cd $HOME
cd bot
cd ltc1
clear
python main.py +13217017725

fi

	if [ $rdhoni = 6 ] || [ $rdhoni = 06 ]
then

cd $HOME
cd bot
cd ltc2
clear
python main.py +13213511423

fi

	if [ $rdhoni = 7 ] || [ $rdhoni = 07 ]
then

cd $HOME
cd bot
cd ltc3
clear
python main.py +13254009879

fi

	if [ $rdhoni = 8 ] || [ $rdhoni = 08 ]
then

cd $HOME
cd bot
cd ltc4
clear
python main.py +13214134409

fi

	if [ $rdhoni = 9 ] || [ $rdhoni = 09 ]
then

cd $HOME
cd bot
cd ltc5
clear
python main.py +16468446957

fi

	if [ $rdhoni = 0 ] || [ $rdhoni = 00 ]
then

echo $r " Goodbye "
sleep 1
echo $r " BY : Moh. Bagus Romadhoni Pratama "
echo $r " Remod By : Rizqi Maulana "
sleep 1
sleep 1
clear
exit

fi
