<?php
//masukan config token yg terdapat pada link di packet captur
// jangan hapus tanda kutip(" ") 

$access_token = 
"xxxxxxx.xxxxxxxxx.xxxxxxx.xxxxxx";

// kamu bisa membuat banyak config untuk beberapa akun.
