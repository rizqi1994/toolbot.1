#info
#BY : Moh Bagus Romadhoni Pratama

clear
cd $HOME
rm -rf toolbot.1
echo
echo
echo " Menginstal Script Yang Di Butuhkan "
echo
echo " BY : Moh Bagus Romadhoni Pratama "
sleep 1
echo
apt update
apt upgrade
apt install php
apt install figlet
apt install cowsay
apt install neofetch
apt install toilet
apt install bash
pip install rsa
pip install pyaes
pip install requests
pip install asyncio
pip install async_generator
pip installcolorama
rm -f /data/data/com.termux/files/usr/bin/bot
rm -f /data/data/com.termux/files/usr/bin/bot.sh
cd bot
mv bot.sh bot
mv -f bot /data/data/com.termux/files/usr/bin/
chmod +x /data/data/com.termux/files/usr/bin/bot
echo
echo
echo " Untuk Menjalankan Ketik (bot) "
sleep 1
sleep 1
sleep 1
rm -f install.sh
cd $HOME